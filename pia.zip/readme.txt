Version 0.29
    Added pruning - removal of redundant measurements
    In settings it is possible to choose save of data ever 5, 10 or 60 seconds.
    In Measurements maintainance it is possible to du pruning with the magnifier icon
    New menus include Export of current measurement as textfile and Removal of redundant
    When starting, it shows "Autostart active" if active
    Added first version of copyright notice...
    
Version 0.28
    added FTP upload & FTP-settings
    improved finding instruments on computer with multiple-ip adresses
    changed main loop so Gorutinenumber is low and under control?!
    
Version 0.27
    changed back SQL-engine
    changed so all exports go to user directory
    run testruns > 1h with instruments
    update main routine
    
Version 0.26
    changed SQL-engine
    changed so all exports go to user directory
    run testruns > 1h with instruments
    
Version 0.25
    added screenshot!
    added correct Y-axis scales
    
Version 0.24
    added feature to save selected windows size!
    fixed irritating bug related to missing preferences file.
    found and corrected bug related to autostart measuring
    changed standard renaming to more compact format
    added PLAY in measurements maintainance
    removed measurements details - counting takes too long when jumping
    change excel-export-filenaming

Version 0.23 (2021-05-16 10:10)
    Serious bug with time handling corrected
    Time correctly exported to excel

Version 0.22
    possible to export one measurement from handle-measurement-window to Excel!
    now possible to change settings & handle measurements while running = good idea?!

Version 0.21
    handle measurements kindof implemented
    now possible to rename measurements (mname), add/edit note, chech out number of datapoints
    BUGFIXES:
        Corrected MyDebug checkbox
        Added so when g.window closes app quits
        Changed so Measurements & Settings close correctly

Version 0.20
New menu item: Help->Check for update
Created webspace (prifre.com/pia) with some documentation
Removed Help->Various information menu
New menu item: Help->Open the PARTICLES IN AIR webpage!

Version 0.19
First release to Anders...
- measuring with AeroTrak, DustTrak, PTrak
- simulated measuring with instruments
- saving of measurements to database
- exporting of database to textfiles
- updating of linecharts in realtime
- some settings:
-- datapoints to show per graph
-- colors for line graph
-- simulated, autostart, synchronized